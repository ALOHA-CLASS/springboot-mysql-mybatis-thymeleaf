package com.human.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration			// 이 클래스를 스프링 설정 빈으로 등록
@EnableWebSecurity		// 이 클래스에 스프링 시큐리티 기능 활성화
public class SecurityConfig extends WebSecurityConfigurerAdapter {
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	// 설정
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		// 인증 : 아이디/비밀번호 로 가입된 사용자 인지 입증
		// 인가 : 사용자에 대한 권한을 부여하는 것
		
		// 인가
		// authorizeRequests() 		: URL 요청에 대한 접근권한 설정
		// antMatchers()			: 경로 지정
		// permitAll()				: 모두에게 접근 허용
		// hasRole(), hasAnyRoles()	: 특정권한을 가진 사용자만 허용
		http.authorizeRequests()
				.antMatchers("/").permitAll()
				.antMatchers("/admin").hasRole("ADMIN")		// 관리자만 접근 허용
				.anyRequest().authenticated()
				;
		
		// 로그인 설정
		http.formLogin()
			.defaultSuccessUrl("/")
			.permitAll()
			;
		
	}
	
	
	// 인 메모리 방식으로 사용자 등록  (이전 방식)
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		// AuthenticationManagerBuilder : 인증 관리 객체
		auth.inMemoryAuthentication()			// 인증방식 : 인메모리 방식으로 지정
			
			// passwordEncoder.encode("비밀번호")  : 비밀번호를 암호화하는 메소드
			// 사용자 등록 - 아이디 / 패스워드 / 권한
			.withUser("user").password( passwordEncoder.encode("123456") ).roles("USER")
			.and()
			// 관리자 등록
			.withUser("admin").password( passwordEncoder.encode("123456") ).roles("ADMIN")
			;
	}
	
	
	// 인 메모리 방식으로 사용자 등록 (최신 방식)
//	@Bean
//	public UserDetailsService users() {
//		UserDetails user = User.builder()
//			.username("user")
//			.password("{bcrypt}$2a$12$SbgZNT6dIHGqAhh6FNrAAeKkMdASdbs6D0eo7NGhKiuEEF9xRG3qm")
//			.roles("USER")
//			.build();
//		UserDetails admin = User.builder()
//			.username("admin")
//			.password("{bcrypt}$2a$12$SbgZNT6dIHGqAhh6FNrAAeKkMdASdbs6D0eo7NGhKiuEEF9xRG3qm")
//			.roles("USER", "ADMIN")
//			.build();
//		return new InMemoryUserDetailsManager(user, admin);
//	}
	

	
	
	
	
	
	
	
	

}















