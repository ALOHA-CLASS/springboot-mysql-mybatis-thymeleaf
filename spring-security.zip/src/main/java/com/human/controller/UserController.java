package com.human.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class UserController {
	
	// 회원가입 화면
	@GetMapping("/join")
	public void join(Model model) throws Exception {
		log.info("회원가입 화면...");
	}

}
