package aloha.domain;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;

@Data
public class Reply {
	
	private int replyNo;
	private String writer;
	private String content;
	private int groupNo;
	private int parentNo;
	private int depthNo;
	private int seqNo;
	private LocalDateTime regDate;
	private LocalDateTime updDate;
	
	private List<Reply> subList;

}
