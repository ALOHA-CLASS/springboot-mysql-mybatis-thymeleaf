package aloha.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import aloha.domain.Reply;

@Mapper
public interface ReplyMapper {
	
	// 댓글 목록
	public List<Reply> list() throws Exception;

}
