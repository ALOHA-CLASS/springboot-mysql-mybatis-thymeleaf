package aloha.service;

import java.util.List;

import aloha.domain.Reply;

public interface ReplyService {
	
	// 댓글 목록
	public List<Reply> list() throws Exception;

}
