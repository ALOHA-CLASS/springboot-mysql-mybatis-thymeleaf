package aloha.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import aloha.domain.Reply;
import aloha.mapper.ReplyMapper;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ReplySerivceImpl implements ReplyService {

	@Autowired
	private ReplyMapper replyMapper;
	
	
	@Override
	public List<Reply> list() throws Exception {
		
		List<Reply> replyList = replyMapper.list();
		
		for (Reply reply : replyList) {
			log.info(reply.toString());
		}
		
		
		return replyList;
	}
	
	

}
