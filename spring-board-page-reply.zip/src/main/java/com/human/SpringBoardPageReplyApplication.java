package com.human;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoardPageReplyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoardPageReplyApplication.class, args);
	}

}
